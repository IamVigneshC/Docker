Container image will get assembled on building the Docker image 

  api-static folder contains all the source files needed 
  nginx folder contains the web serving needs
